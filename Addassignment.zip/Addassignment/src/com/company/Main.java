package com.company;
import com.company.House.House;
import com.company.House.HouseBuilder;
import com.company.House.HouseBuilderImpl;

public class Main {

    public static void main(String[] args) {
        House house = new HouseBuilderImpl().buildDoors(3).buildRoof(1).buildGarage(true).buildWalls(4).buildWindows(3).getResult();
        house.print();
    }
}
