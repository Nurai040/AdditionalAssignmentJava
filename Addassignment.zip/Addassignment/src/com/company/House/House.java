package com.company.House;

public class House {
    int walls;
    int doors;
    int windows;
    int roof;
    boolean garage;

    public void print(){
        System.out.println("walls: "+walls+" doors: "+doors+" windows: "+windows+" roof: "+roof+" garage: "+garage);
    }
}
