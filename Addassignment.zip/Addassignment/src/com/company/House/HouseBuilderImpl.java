package com.company.House;

public class HouseBuilderImpl implements HouseBuilder{
    House house = new House();

    @Override
    public HouseBuilder buildWalls(int am) {
        house.walls=am;
        return this;
    }

    @Override
    public HouseBuilder buildDoors(int amount) {
        house.doors=amount;
        return this;
    }

    @Override
    public HouseBuilder buildWindows(int kol) {
        house.windows=kol;
        return this;
    }

    @Override
    public HouseBuilder buildRoof(int col) {
        house.roof = col;
        return this;
    }

    @Override
    public HouseBuilder buildGarage(boolean exist) {
        house.garage = exist;
        return this;
    }

    @Override
    public House getResult() {
        return house;
    }
}
