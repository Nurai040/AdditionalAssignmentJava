package com.company.House;

public interface HouseBuilder {
    HouseBuilder buildWalls(int am);
    HouseBuilder buildDoors(int amount);
    HouseBuilder buildWindows(int kol);
    HouseBuilder buildRoof(int col);
    HouseBuilder buildGarage(boolean exist);
    House getResult();
}
